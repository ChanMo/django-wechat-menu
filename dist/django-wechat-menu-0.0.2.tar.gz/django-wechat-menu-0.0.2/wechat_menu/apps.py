from django.apps import AppConfig


class WechatMenuConfig(AppConfig):
    name = 'wechat_menu'
